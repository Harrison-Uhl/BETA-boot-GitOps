//! # rar-chat binary — terminal loop and history-commit policy
//!
//! Usage:
//! ```text
//!   rar-chat [ENV_FILE]
//! ```
//! `ENV_FILE` is an optional path to a KEY=VALUE configuration file (syntax:
//! DEC-CHAT-02). Keys found there take precedence over the process
//! environment (INV-CHAT-02); with no argument, the process environment
//! alone is used. See `nvidia.env.example` / `openai.env.example`.
//!
//! ## History-commit policy (the fix for the reviewed draft's broken
//! multi-turn behavior)
//! - The user line is pushed to history before the call.
//! - On `Ok(outcome)`: the assistant reply is pushed from
//!   `outcome.content` — the machine-assembled full text, not anything
//!   captured in the display handler (INV-CHAT-10).
//! - On `Err`: the user line is popped and the operator is told the turn
//!   is not in history. Text already on screen from a truncated stream is
//!   display residue only; it was never committed (INV-CHAT-03/04).
//!   DEC-CHAT-11: pop-and-retype over keep-and-retry — an uncommitted user
//!   line cannot silently desynchronize what the operator sees from what
//!   the model will be sent next turn.

use anyhow::Result;
use rar_chat::driver::{DriverEvent, DriverFault};
use rar_chat::env_file::EnvSource;
use rar_chat::event_handler::{DriverControlFlow, DriverEventHandler};
use rar_chat::openai::{Message, OpenAiCompatDriver, OpenAiConfig};
use std::io::Write;
use std::path::PathBuf;
use std::time::Duration;
use tokio::io::{self, AsyncBufReadExt, BufReader};

/// Presentation-only handler: prints deltas and telemetry. Keeps no state
/// (INV-CHAT-10) — history is committed in `main` from the `ChatOutcome`.
pub struct TerminalLoggerHandler;

impl DriverEventHandler for TerminalLoggerHandler {
    fn handle_telemetry(&self, tag: &str, bytes: usize, duration: Duration) -> DriverControlFlow {
        match tag {
            "ttft" => eprintln!(
                "\n[METRIC] TTFT: {}ms | Chunk Size: {} bytes",
                duration.as_millis(),
                bytes
            ),
            t if t.starts_with("protocol_anomaly") => eprintln!("\n[ANOMALY] {t}"),
            "eof_without_done_sentinel" => {
                eprintln!("\n[NOTE] stream ended after finish_reason without [DONE] (tolerated)")
            }
            _ => {}
        }
        DriverControlFlow::Continue
    }

    fn handle_delta(&self, fragment: &str) -> DriverControlFlow {
        print!("{fragment}");
        let _ = std::io::stdout().flush();
        DriverControlFlow::Continue
    }

    fn handle_event(&self, event: &DriverEvent) -> DriverControlFlow {
        match event {
            DriverEvent::Finish(reason) => {
                eprintln!("\n[SYSTEM] Stream completed. Exit Reason: {reason}");
            }
            DriverEvent::Usage { prompt_tokens, completion_tokens, total_tokens } => {
                eprintln!(
                    "[ACCOUNTING] Token Usage Ledger -> Prompt: {prompt_tokens}, Completion: {completion_tokens}, Total: {total_tokens}"
                );
            }
            _ => {}
        }
        DriverControlFlow::Continue
    }
}

#[tokio::main(flavor = "current_thread")]
async fn main() -> Result<()> {
    // --- configuration: optional env-file argument, then process env ---
    let mut args = std::env::args().skip(1);
    let source = match args.next() {
        Some(flag) if flag == "-h" || flag == "--help" => {
            eprintln!("usage: rar-chat [ENV_FILE]");
            eprintln!("  ENV_FILE  optional KEY=VALUE file; keys override the process environment");
            eprintln!("  keys: OPENAI_API_KEY (req), OPENAI_MODEL (req), OPENAI_BASE_URL,");
            eprintln!("        OPENAI_SYSTEM, OPENAI_INCLUDE_USAGE, OPENAI_STALL_SECS");
            return Ok(());
        }
        Some(path) => EnvSource::from_file(&PathBuf::from(path))?,
        None => EnvSource::process_only(),
    };
    let cfg = OpenAiConfig::from_source(&source)?;
    let system_prompt = cfg.system_prompt.clone();
    // INV-CHAT-01: announce endpoint and model — never the key.
    eprintln!(
        "rar-chat — endpoint {} | model {} | config {}",
        cfg.base_url,
        cfg.model,
        source.origin.as_deref().unwrap_or("(process environment)")
    );
    eprintln!("commands: /quit  /reset (Ctrl-D also quits)");

    let driver = OpenAiCompatDriver::new(cfg);
    let handler = TerminalLoggerHandler;

    let mut history: Vec<Message> = Vec::new();
    if let Some(sys) = system_prompt {
        history.push(Message::new("system", &sys));
    }

    let mut lines = BufReader::new(io::stdin()).lines();
    loop {
        print!("you> ");
        std::io::stdout().flush()?;
        let Some(line) = lines.next_line().await? else { break };
        let line = line.trim();
        if line.is_empty() {
            continue;
        }

        match line {
            "/quit" | "/exit" => break,
            "/reset" => {
                history.retain(|m| m.role == "system");
                eprintln!("(history cleared)");
                continue;
            }
            _ => {}
        }

        history.push(Message::new("user", line));
        print!("ai> ");
        std::io::stdout().flush()?;

        match driver.execute_chat(&history, &handler).await {
            Ok(outcome) => {
                // The commit point: full assembled reply enters history so
                // the model sees its own prior turns.
                history.push(Message::new("assistant", &outcome.content));
            }
            Err(e) => {
                history.pop(); // DEC-CHAT-11
                match e.downcast_ref::<DriverFault>() {
                    Some(fault) => eprintln!("\n[TURN FAILED] {fault} — turn not committed to history"),
                    None => eprintln!("\nExecution stream error: {e:#} — turn not committed to history"),
                }
            }
        }
        println!();
    }
    Ok(())
}
