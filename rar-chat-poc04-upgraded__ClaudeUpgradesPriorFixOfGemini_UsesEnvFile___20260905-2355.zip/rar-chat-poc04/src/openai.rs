//! # openai — transport driver for OpenAI-compatible chat-completions endpoints
//!
//! ## Role in the system
//! The trusted transport layer: builds the HTTP request, owns the network
//! stream, reassembles SSE frames (`sse.rs`), normalizes them into
//! `DriverEvent`s, feeds completion semantics (`machine.rs`), and calls the
//! registered `DriverEventHandler` per the ratified callback direction — the
//! Driver holds the handler reference and reacts to its returned statuses;
//! the handler holds no reference to the Driver or anything else here.
//!
//! ## Verified endpoint flavors
//! The wire contract used (POST `{base}/chat/completions`, `Authorization:
//! Bearer`, `stream: true`, `data:` SSE frames, `data: [DONE]` sentinel) is
//! verified against:
//! - OpenAI Chat Completions:
//!   https://platform.openai.com/docs/api-reference/chat/create
//! - NVIDIA NIM hosted catalog (base URL
//!   https://integrate.api.nvidia.com/v1, key from
//!   https://build.nvidia.com/settings, model strings like
//!   "nvidia/llama-3.1-nemotron-70b-instruct"):
//!   https://docs.api.nvidia.com/nim/reference/llm-apis
//!   (verified 2026-09-05)
//!
//! ## Invariants
//! - INV-CHAT-01 (upheld here): the API key is attached to the request and
//!   appears in no log line, no error string, and no telemetry field.
//! - INV-CHAT-08: every ending of `execute_chat` passes through
//!   `StreamMachine::finalize` — there is no code path that returns success
//!   without the completion criterion (INV-CHAT-04) being met.
//! - INV-CHAT-09: liveness is timer-enforced. Between-read stalls longer
//!   than the configured window produce `DriverFault::Stalled` (fixes the
//!   reviewed draft, whose "heartbeat guardrail" could only fire when the
//!   peer sent bytes — the one thing a stalled peer never does).
//!
//! ## Decisions
//! - DEC-CHAT-08: `stream_options.include_usage` is sent only when
//!   configured on; a missing usage frame is never an error (per-model
//!   support varies across OpenAI-compatible vendors — see NIM notes above).
//! - DEC-CHAT-09: The concrete type is named for what it is —
//!   `OpenAiCompatDriver`, an OpenAI-*compatible* transport — replacing the
//!   misleading `NvidiaNimDriver` (which defaulted to api.openai.com). The
//!   vendor is a property of the loaded configuration, not of the type.

use crate::driver::{ChatOutcome, DriverEvent, DriverFault};
use crate::env_file::EnvSource;
use crate::event_handler::{DriverControlFlow, DriverEventHandler};
use crate::machine::{EndCause, StreamMachine};
use crate::sse::{SseParser, SsePayload, DEFAULT_BUF_LIMIT};
use anyhow::{anyhow, Context, Result};
use futures_util::StreamExt;
use serde::{Deserialize, Serialize};
use std::time::{Duration, Instant};

/// Configuration keys read (via [`EnvSource`]: env file first, then process
/// environment — INV-CHAT-02):
///
/// | key                  | required | default                      |
/// |----------------------|----------|------------------------------|
/// | `OPENAI_API_KEY`     | yes      | —                            |
/// | `OPENAI_MODEL`       | yes      | —                            |
/// | `OPENAI_BASE_URL`    | no       | `https://api.openai.com/v1`  |
/// | `OPENAI_SYSTEM`      | no       | (no system message)          |
/// | `OPENAI_INCLUDE_USAGE`| no      | `1` (send `stream_options`)  |
/// | `OPENAI_STALL_SECS`  | no       | `30`                         |
///
/// DEC-CHAT-10: `OPENAI_MODEL` is required, not defaulted. A model default
/// belongs to a vendor; this driver serves many vendors, and a silently
/// wrong default (e.g. an OpenAI model name sent to NIM) fails confusingly
/// at the far end. Fail loudly at load instead.
#[derive(Debug, Clone)]
pub struct OpenAiConfig {
    pub base_url: String,
    pub api_key: String,
    pub model: String,
    pub request_usage: bool,
    pub stall_timeout: Duration,
    pub system_prompt: Option<String>,
}

impl OpenAiConfig {
    pub fn from_source(src: &EnvSource) -> Result<Self> {
        let api_key = src
            .get("OPENAI_API_KEY")
            .context("OPENAI_API_KEY is not set (env file or process environment)")?;
        let model = src
            .get("OPENAI_MODEL")
            .context("OPENAI_MODEL is not set — required, no default (DEC-CHAT-10)")?;
        let base_url = src
            .get("OPENAI_BASE_URL")
            .unwrap_or_else(|| "https://api.openai.com/v1".to_string());
        let request_usage = !matches!(
            src.get("OPENAI_INCLUDE_USAGE").as_deref(),
            Some("0") | Some("false") | Some("no")
        );
        let stall_secs: u64 = match src.get("OPENAI_STALL_SECS") {
            Some(s) => s
                .parse()
                .context("OPENAI_STALL_SECS must be an integer number of seconds")?,
            None => 30,
        };
        Ok(Self {
            base_url: base_url.trim_end_matches('/').to_string(),
            api_key,
            model,
            request_usage,
            stall_timeout: Duration::from_secs(stall_secs),
            system_prompt: src.get("OPENAI_SYSTEM"),
        })
    }
}

#[derive(Debug, Clone, Serialize, Deserialize)]
pub struct Message {
    pub role: String,
    pub content: String,
}

impl Message {
    pub fn new(role: &str, content: &str) -> Self {
        Self { role: role.to_string(), content: content.to_string() }
    }
}

#[derive(Serialize)]
struct StreamOptions {
    include_usage: bool,
}

#[derive(Serialize)]
struct ChatRequest<'a> {
    model: &'a str,
    messages: &'a [Message],
    stream: bool,
    #[serde(skip_serializing_if = "Option::is_none")]
    stream_options: Option<StreamOptions>,
}

#[derive(Deserialize)]
struct Chunk {
    #[serde(default)]
    choices: Vec<Choice>,
    usage: Option<Usage>,
    error: Option<serde_json::Value>,
}

#[derive(Deserialize)]
struct Choice {
    #[serde(default)]
    delta: Delta,
    finish_reason: Option<String>,
}

#[derive(Deserialize, Default)]
struct Delta {
    content: Option<String>,
}

#[derive(Deserialize)]
struct Usage {
    pub prompt_tokens: u32,
    pub completion_tokens: u32,
    pub total_tokens: u32,
}

/// Normalize one SSE `data:` payload into zero or more `DriverEvent`s.
/// Pure function — unit-tested without a network.
pub fn events_from_data(data: &str) -> Result<Vec<DriverEvent>> {
    if data.trim() == "[DONE]" {
        return Ok(vec![DriverEvent::Done]);
    }
    let chunk: Chunk = serde_json::from_str(data)
        .map_err(|e| DriverFault::Protocol(format!("unparseable chunk: {e}")))
        .map_err(anyhow::Error::from)?;
    if let Some(err) = chunk.error {
        return Err(anyhow!(DriverFault::Protocol(format!("server error in stream: {err}"))));
    }
    let mut out = Vec::new();
    for c in chunk.choices {
        if let Some(t) = c.delta.content {
            if !t.is_empty() {
                out.push(DriverEvent::TextDelta(t));
            }
        }
        if let Some(r) = c.finish_reason {
            out.push(DriverEvent::Finish(r));
        }
    }
    if let Some(u) = chunk.usage {
        out.push(DriverEvent::Usage {
            prompt_tokens: u.prompt_tokens,
            completion_tokens: u.completion_tokens,
            total_tokens: u.total_tokens,
        });
    }
    Ok(out)
}

/// Transport driver for any OpenAI-compatible chat-completions endpoint
/// (DEC-CHAT-09). Vendor identity lives in `OpenAiConfig`, not here.
pub struct OpenAiCompatDriver {
    client: reqwest::Client,
    cfg: OpenAiConfig,
}

impl OpenAiCompatDriver {
    pub fn new(cfg: OpenAiConfig) -> Self {
        Self {
            // Connect timeout guards the dial; the per-read stall timer
            // (INV-CHAT-09) guards the stream. No overall deadline — long
            // generations are legitimate as long as bytes keep flowing.
            client: reqwest::Client::builder()
                .connect_timeout(Duration::from_secs(15))
                .build()
                .expect("reqwest client construction cannot fail with these options"),
            cfg,
        }
    }

    pub fn config(&self) -> &OpenAiConfig {
        &self.cfg
    }

    /// Run one streaming chat call to completion (or typed fault).
    ///
    /// Event flow per network read:
    ///   bytes -> SseParser -> events_from_data -> StreamMachine::feed
    ///        -> handler callbacks (telemetry / delta / event)
    ///
    /// Returns `Ok(ChatOutcome)` only via `StreamMachine::finalize`
    /// (INV-CHAT-08). The caller commits `outcome.content` to history;
    /// nothing is committed on `Err`.
    pub async fn execute_chat(
        &self,
        messages: &[Message],
        handler: &dyn DriverEventHandler,
    ) -> Result<ChatOutcome> {
        let url = format!("{}/chat/completions", self.cfg.base_url);
        let body = ChatRequest {
            model: &self.cfg.model,
            messages,
            stream: true,
            stream_options: self
                .cfg
                .request_usage
                .then_some(StreamOptions { include_usage: true }), // DEC-CHAT-08
        };

        let resp = self
            .client
            .post(&url)
            .bearer_auth(&self.cfg.api_key) // INV-CHAT-01: sole use of the key
            .json(&body)
            .send()
            .await
            .with_context(|| format!("failed connection to {url}"))?;

        let status = resp.status();
        if !status.is_success() {
            let text = resp.text().await.unwrap_or_default();
            return Err(anyhow!("HTTP {status}: {text}"));
        }

        let mut parser = SseParser::with_limit(DEFAULT_BUF_LIMIT);
        let mut machine = StreamMachine::new();
        let mut stream = resp.bytes_stream();
        let start_time = Instant::now();
        let mut last_packet_time = Instant::now();
        let mut is_first_token = true;

        loop {
            // INV-CHAT-09: the timer speaks for a silent peer.
            let next = tokio::time::timeout(self.cfg.stall_timeout, stream.next()).await;
            let item = match next {
                Err(_elapsed) => {
                    return Err(anyhow!(DriverFault::Stalled {
                        after_secs: self.cfg.stall_timeout.as_secs()
                    }));
                }
                Ok(None) => break, // EOF — verdict comes from the machine
                Ok(Some(item)) => item,
            };
            let bytes = item.context("stream packet read error")?;
            let now = Instant::now();
            let duration = now.duration_since(last_packet_time);
            last_packet_time = now;

            let frames = parser
                .push(&bytes)
                .map_err(|o| DriverFault::BufferOverflow { limit_bytes: o.limit_bytes })?;

            for ev in frames {
                let byte_len = ev.raw_byte_len;
                match ev.payload {
                    SsePayload::Comment(_) => {
                        // Keep-alive ping: telemetry only. Liveness authority
                        // moved to the stall timer (INV-CHAT-09); the handler
                        // may still abort on it if it has its own policy.
                        if handler.handle_telemetry("keep_alive_heartbeat", byte_len, duration)
                            == DriverControlFlow::AbortStream
                        {
                            return Err(anyhow!(DriverFault::Aborted {
                                partial_chars: machine.partial_chars()
                            }));
                        }
                    }
                    SsePayload::Data(data_str) => {
                        for de in events_from_data(&data_str)? {
                            machine.feed(&de);
                            let control = match &de {
                                DriverEvent::TextDelta(t) => {
                                    if is_first_token {
                                        is_first_token = false;
                                        handler.handle_telemetry(
                                            "ttft",
                                            byte_len,
                                            now.duration_since(start_time),
                                        );
                                    }
                                    // NOTE: gap is measured between network
                                    // reads; events parsed from one read
                                    // share a duration. Known imprecision,
                                    // acceptable for POC telemetry.
                                    handler.handle_telemetry("inter_token_gap", byte_len, duration);
                                    handler.handle_delta(t)
                                }
                                _ => handler.handle_event(&de),
                            };

                            if control == DriverControlFlow::AbortStream {
                                return Err(anyhow!(DriverFault::Aborted {
                                    partial_chars: machine.partial_chars()
                                }));
                            }

                            if matches!(de, DriverEvent::Done) {
                                // Consume the sentinel and stop reading; the
                                // verdict is still the machine's alone
                                // (INV-CHAT-08, DEC-CHAT-04).
                                return finalize(machine, parser, handler);
                            }
                        }
                    }
                }
            }
        }

        // EOF without [DONE]: recover any unterminated tail frame first.
        for ev in parser.finish() {
            if let SsePayload::Data(data_str) = ev.payload {
                for de in events_from_data(&data_str)? {
                    machine.feed(&de);
                }
            }
        }
        if machine.is_completable() && !machine.saw_done() {
            handler.handle_telemetry("eof_without_done_sentinel", 0, Duration::ZERO);
        }
        emit_anomalies(&machine, handler);
        machine
            .finalize(EndCause::StreamEnded)
            .map_err(anyhow::Error::from)
    }
}

/// Shared exit path for the `[DONE]` return (parser already consumed).
fn finalize(
    machine: StreamMachine,
    _parser: SseParser,
    handler: &dyn DriverEventHandler,
) -> Result<ChatOutcome> {
    emit_anomalies(&machine, handler);
    machine
        .finalize(EndCause::StreamEnded)
        .map_err(anyhow::Error::from)
}

/// Surface DEC-CHAT-05 anomaly notes as telemetry tags — evidence kept,
/// stream not failed.
fn emit_anomalies(machine: &StreamMachine, handler: &dyn DriverEventHandler) {
    for note in &machine.anomalies {
        handler.handle_telemetry(&format!("protocol_anomaly: {note}"), 0, Duration::ZERO);
    }
}

#[cfg(test)]
mod tests {
    use super::*;

    #[test]
    fn done_sentinel_maps_to_done_event() {
        assert_eq!(events_from_data("[DONE]").unwrap(), vec![DriverEvent::Done]);
    }

    #[test]
    fn delta_and_finish_in_one_chunk() {
        let evs = events_from_data(
            r#"{"choices":[{"delta":{"content":"hi"},"finish_reason":"stop"}]}"#,
        )
        .unwrap();
        assert_eq!(
            evs,
            vec![
                DriverEvent::TextDelta("hi".into()),
                DriverEvent::Finish("stop".into())
            ]
        );
    }

    #[test]
    fn usage_frame_with_empty_choices() {
        // The include_usage final chunk has `choices: []` (OpenAI contract).
        let evs = events_from_data(
            r#"{"choices":[],"usage":{"prompt_tokens":1,"completion_tokens":2,"total_tokens":3}}"#,
        )
        .unwrap();
        assert_eq!(
            evs,
            vec![DriverEvent::Usage { prompt_tokens: 1, completion_tokens: 2, total_tokens: 3 }]
        );
    }

    #[test]
    fn in_stream_server_error_is_protocol_fault() {
        let err = events_from_data(r#"{"error":{"message":"boom"}}"#).unwrap_err();
        assert!(err.downcast_ref::<DriverFault>().is_some());
    }
}
