//! # rar-chat — minimal terminal chat over OpenAI-compatible streaming APIs
//!
//! POC chunk 02 of the RAR Driver build thread. The module graph, from wire
//! to policy:
//!
//! ```text
//!   network bytes
//!       │  sse.rs        frame reassembly (bounded buffer)      INV-CHAT-06/07
//!       ▼
//!   SSE frames
//!       │  openai.rs     transport, auth, normalization         INV-CHAT-01/08/09
//!       ▼
//!   DriverEvents ──────► event_handler.rs   observer callbacks  INV-CHAT-10
//!       │  machine.rs    completion semantics (pure, tested)    INV-CHAT-04/05
//!       ▼
//!   ChatOutcome / DriverFault ──► main.rs   history commit policy
//!
//!   env_file.rs   configuration source (file → process env)     INV-CHAT-01/02
//!   driver.rs     shared vocabulary: events, outcome, faults    INV-CHAT-03
//! ```
//!
//! ## Instrumentation registry (session-minted DRAFT series `CHAT`)
//! Invariants: INV-CHAT-01 no secret in logs/errors · 02 config lookup
//! precedence · 03 events ≠ outcome · 04 finish_reason is the completion
//! criterion · 05 content is unedited testimony · 06 bounded SSE buffer ·
//! 07 UTF-8 decode on whole frames only · 08 all exits pass finalize ·
//! 09 timer-enforced liveness · 10 handlers are stateless observers.
//! Decisions: DEC-CHAT-01 no dotenv dep · 02 env-file syntax · 03 faults as
//! hand-written error enum · 04 [DONE] carries no completion authority ·
//! 05 tolerate-and-flag late text · 06 dual frame terminators · 07 ignore
//! non-data SSE fields · 08 usage optional per vendor · 09 driver named for
//! the contract, not a vendor · 10 model has no default.
//! Renumber at registry merge per the standing allocation law.

pub mod driver;
pub mod env_file;
pub mod event_handler;
pub mod machine;
pub mod openai;
pub mod sse;
