//! # event_handler — the guest-side callback seam
//!
//! ## Role in the system
//! This trait is the seam where presentation/observation logic plugs into
//! the trusted transport, in the ratified direction: the Driver holds a
//! `&dyn DriverEventHandler`, calls its methods as the stream progresses,
//! and reacts to each returned `DriverControlFlow`. An implementation holds
//! no reference to the Driver, the parser, or the network — it can observe
//! and it can ask to stop; it cannot reach anything ("capability by
//! construction, not guards").
//!
//! ## Invariants
//! - INV-CHAT-10: Handler methods take `&self` and the trait is
//!   `Send + Sync`; implementations must be internally synchronized if they
//!   keep state. Handlers are observers — conversation state (history) is
//!   owned by the caller of `execute_chat` and committed only from the
//!   returned `ChatOutcome`, never assembled inside a handler (the reviewed
//!   draft's lost-history defect came from blurring exactly this line).

use crate::driver::DriverEvent;
use std::time::Duration;

/// What the handler wants the transport to do after a callback.
#[derive(Debug, Clone, Copy, PartialEq, Eq)]
pub enum DriverControlFlow {
    Continue,
    /// Ask the transport to stop; surfaces as `DriverFault::Aborted`,
    /// distinct from truncation and stall by type.
    AbortStream,
}

pub trait DriverEventHandler: Send + Sync {
    /// Transport telemetry: `tag` identifies the metric ("ttft",
    /// "inter_token_gap", "keep_alive_heartbeat", "protocol_anomaly: ...",
    /// "eof_without_done_sentinel"), `bytes` the frame size where relevant.
    fn handle_telemetry(&self, tag: &str, bytes: usize, duration: Duration) -> DriverControlFlow;

    /// One fragment of assistant text, in order. Presentation only —
    /// see INV-CHAT-10 for why accumulation does not belong here.
    fn handle_delta(&self, fragment: &str) -> DriverControlFlow;

    /// Non-delta events (finish reason, usage, done sentinel).
    fn handle_event(&self, event: &DriverEvent) -> DriverControlFlow;
}
