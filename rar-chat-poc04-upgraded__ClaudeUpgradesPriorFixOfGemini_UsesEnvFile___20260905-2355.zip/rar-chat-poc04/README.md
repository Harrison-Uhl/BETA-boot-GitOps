# rar-chat — POC chunk 02 (upgraded)

Minimal terminal chat over any OpenAI-compatible streaming chat-completions
endpoint. This revision upgrades the Gemini-produced chunk-02 draft: env-file
configuration by argument, correct multi-turn history, finish_reason-gated
completion semantics, timer-enforced stall detection, a bounded SSE buffer,
and inline INV-/DEC- instrumentation throughout (registry in `src/lib.rs`).

## Build

Pinned to build on cargo/rustc 1.75 (Ubuntu 24.04 apt toolchain); the
committed `Cargo.lock` reproduces the verified dependency graph. On a rustup
toolchain you may loosen the `=` pins in `Cargo.toml`.

    cargo build --release
    cargo test          # 21 unit tests: env parsing, SSE framing, completion semantics

## Run

    rar-chat [ENV_FILE]

`ENV_FILE` is a KEY=VALUE file (comments `#`, optional `export`, optional
matching quotes). Keys found in the file override the process environment;
with no argument, the process environment alone is used. Copy an example and
fill in your key — and protect it: `chmod 600 nvidia.env`, never commit it
(`.gitignore` already excludes `*.env`).

| key                    | required | default                     |
|------------------------|----------|-----------------------------|
| `OPENAI_API_KEY`       | yes      | —                           |
| `OPENAI_MODEL`         | yes      | — (no default: DEC-CHAT-10) |
| `OPENAI_BASE_URL`      | no       | `https://api.openai.com/v1` |
| `OPENAI_SYSTEM`        | no       | (none)                      |
| `OPENAI_INCLUDE_USAGE` | no       | `1`                         |
| `OPENAI_STALL_SECS`    | no       | `30`                        |

### NVIDIA NIM

    cp nvidia.env.example nvidia.env    # edit: paste your nvapi- key
    chmod 600 nvidia.env
    ./target/release/rar-chat nvidia.env

The wire contract this driver speaks (POST `{base}/chat/completions`, bearer
auth, `stream: true`, SSE `data:` frames, `data: [DONE]` sentinel) is
verified against NVIDIA's NIM hosted catalog, which documents its LLM APIs
as OpenAI-compatible at base URL `https://integrate.api.nvidia.com/v1` with
keys from build.nvidia.com. `stream_options.include_usage` is an OpenAI
extension with per-model support variance on compatible endpoints; a missing
usage frame is never treated as an error, and `OPENAI_INCLUDE_USAGE=0` drops
the request field entirely if a model rejects it.

## Behavior contracts (summary — full registry in src/lib.rs)

- A turn commits to history only from a completed `ChatOutcome`; a
  `finish_reason` from the server — not `[DONE]`, not end-of-stream — is the
  completion criterion. Truncated, aborted, and stalled streams are distinct
  typed faults, and none of them commits anything.
- The API key is read from the env file or process environment, attached to
  the request, and appears in no log line or error message.
- The SSE reassembly buffer is bounded (1 MiB); UTF-8 is decoded only on
  complete frames.

## References

1. NVIDIA, "LLM APIs" — NIM API reference (base URL, endpoint, model table).
   https://docs.api.nvidia.com/nim/reference/llm-apis
2. NVIDIA, API Catalog and key generation.
   https://build.nvidia.com/ and https://build.nvidia.com/settings
3. OpenAI, "Create chat completion" — API reference (the compatibility
   target, including stream_options.include_usage semantics).
   https://platform.openai.com/docs/api-reference/chat/create
4. WHATWG, HTML Living Standard §9.2 "Server-sent events" (frame grammar,
   data-line joining, comment frames).
   https://html.spec.whatwg.org/multipage/server-sent-events.html
